# Fork vs Spoon V2 > 2025-01-12 2:26pm
https://universe.roboflow.com/spoon-jenxr/fork-vs-spoon-v2-izlyx

Provided by a Roboflow user
License: CC BY 4.0

